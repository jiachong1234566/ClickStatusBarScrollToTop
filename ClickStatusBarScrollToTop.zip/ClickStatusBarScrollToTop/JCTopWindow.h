//
//  WNXTopWindow.h
//  DaboPlayer
//
//  Created by 贾崇 on 2017/8/24.
//  Copyright © 2017年 dabo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCTopWindow : NSObject

+ (void)show;
+ (void)hide;

@end
